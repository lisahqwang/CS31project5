//
//  FrequentFlyerAccount.h
//  FrequentFlyerAccount
//  Students should copy below the contents of their FrequentFlyerAccount.h file
//


//.h file for FFA
#ifndef FREQUENTFLYERACCOUNT_H
#define FREQUENTFLYERACCOUNT_H
#include <iostream>
#include <string>
#include "PlaneFlight.h"
class FrequentFlyerAccount {
public:
	FrequentFlyerAccount(string name);

	string getName();
	double getBalance();
	bool addFlightToAccount(PlaneFlight& flight);
	bool canEarnFreeFlight(double mileage);
	bool freeFlight(string FromCity, string ToCity, double Mileage, PlaneFlight& flight);

private:
	string mName;
	double mBalance;
};



#endif